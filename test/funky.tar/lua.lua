function bar_baz(v)
  return v
end

function dot.by_dot()
  return 0
end

local function foo(params)
  return 0
end

local function one_line(value) return 1 end

local local_foo = function()
  return 0
end

local o = {}

o.fun1 = function(client, buffer)
  return 1
end
