(ns tacahiroy
  (:use [clojure.contrib.str-utils2 :only (chomp blank?)]))

(defn get-user-input []
  (loop []
    (print "> ")
    (flush)

    (def input (chomp (read-line)))
    (if (not(blank? input))
      input
      (recur))))

(def private-fu []
  (print "private-fu"))

