#!python3
class Vim:
    def editor():
        print("Vi Improved")


class CtrlP:
    def method():
        print("ctrlp!")


class Funky():
    def funk():
        print("funk")

    def saturday(night, fever):
        print("dancing")

    def sleeping():
        print("zzZ")

    def monday():
        print("absent")

    def async_func():
        print('async')


if __name__ == "__main__":
    v = Vim()
    v.editor()
