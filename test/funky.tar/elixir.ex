defmodule FakeStar do
  def rndnum(len) when is_integer len do
    :crypto.strong_rand_bytes(len)
  end

  def rndstr(len) do
    rndnum(len)
    |> :base64.encode_to_string
    |> to_string
  end

  defp priv_func() do
    IO.puts 'private'
  end

  defmacro this_is_a_macro() do
    IO.puts 'this_is_a_macro'
  end
end
