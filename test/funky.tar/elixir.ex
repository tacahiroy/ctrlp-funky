defmodule FakeStar do
  def rndnum(len) when is_integer len do
    :crypto.strong_rand_bytes(len)
  end

  def rndstr(len) do
    rndnum(len)
    |> :base64.encode_to_string
    |> to_string
  end
end
