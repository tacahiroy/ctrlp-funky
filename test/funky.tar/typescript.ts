enum Game {
  NES,
  SNES,
  Genesis,
  NeoGeo
}

declare module Module1 {
    export class Klass1 {
        constructor (arg1);
    }
    export class Klass2<T> {
        constructor ();
    }
}
interface Interfa1 {
    on(): Module1;
    off(): Module1;
}
declare var bar {
    (v: Value): Module1;
};
declare var : any;


// Klass3
class Klass3 extends SuperKlass {

    init() {
      return true;
    }

    initialize() {
      return true;
    }

}
