enum Game {
  NES,
  SNES,
  Genesis,
  NeoGeo
}

declare module Module1 {
    export class Klass1 {
        constructor (arg1);
    }
    export class Klass2<T> {
        constructor ();
    }
}
interface Interfa1 {
    on(): Module1;
    off(): Module1;
}
declare var bar {
    (v: Value): Module1;
};
declare var : any;


// Person
export class Preson extends SuperKlass {
  private _fname: string;
  private _lname: string;

  constructor(fname, lname) {
    this._fname = fname;
    this._lname = lname;
  }

  public firstName() {
    return this._fname;
  }

  public lastName() {
    return this._lname;
  }

  fullName() {
    return this.firstName() + " " + this.lastName();
  }
}
