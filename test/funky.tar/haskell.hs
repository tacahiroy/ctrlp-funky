square :: (Num a) => a -> a
square x = x * x

triangle :: (Num a) => a -> a
