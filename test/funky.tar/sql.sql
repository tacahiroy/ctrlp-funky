CREATE FUNCTION tst();
CREATE OR REPLACE FUNCTION schema.test();
CREATE OR REPLACE FUNCTION schema.test_args(multi number,
                        line varchar2,
                        arguments number);
CREATE OR REPLACE FUNCTION schema.test_noparens;
CREATE OR REPLACE FUNCTION schema.test_noparens_args(arguments number);
